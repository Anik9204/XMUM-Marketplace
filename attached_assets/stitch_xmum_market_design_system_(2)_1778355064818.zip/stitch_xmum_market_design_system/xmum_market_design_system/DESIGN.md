---
name: XMUM Market Design System
colors:
  surface: '#f9f9fe'
  surface-dim: '#dad9de'
  surface-bright: '#f9f9fe'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f8'
  surface-container: '#eeedf2'
  surface-container-high: '#e8e8ed'
  surface-container-highest: '#e2e2e7'
  on-surface: '#1a1c1f'
  on-surface-variant: '#43474f'
  inverse-surface: '#2f3034'
  inverse-on-surface: '#f1f0f5'
  outline: '#737780'
  outline-variant: '#c3c6d1'
  surface-tint: '#3a5f94'
  primary: '#001e40'
  on-primary: '#ffffff'
  primary-container: '#003366'
  on-primary-container: '#799dd6'
  inverse-primary: '#a7c8ff'
  secondary: '#0054ca'
  on-secondary: '#ffffff'
  secondary-container: '#336ee5'
  on-secondary-container: '#fefcff'
  tertiary: '#381300'
  on-tertiary: '#ffffff'
  tertiary-container: '#592300'
  on-tertiary-container: '#d8885c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d5e3ff'
  primary-fixed-dim: '#a7c8ff'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#1f477b'
  secondary-fixed: '#dae2ff'
  secondary-fixed-dim: '#b1c5ff'
  on-secondary-fixed: '#001947'
  on-secondary-fixed-variant: '#00419f'
  tertiary-fixed: '#ffdbca'
  tertiary-fixed-dim: '#ffb690'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#723610'
  background: '#f9f9fe'
  on-background: '#1a1c1f'
  surface-variant: '#e2e2e7'
  success: '#10B981'
  warning: '#F59E0B'
  danger: '#EF4444'
  bg-light: '#F8FAFC'
  surface-light: '#FFFFFF'
  border-light: '#E2E8F0'
  text-primary-light: '#0F172A'
  text-secondary-light: '#64748B'
  bg-dark: '#0F172A'
  surface-dark: '#1E293B'
  border-dark: '#334155'
  text-primary-dark: '#F1F5F9'
  text-secondary-dark: '#94A3B8'
typography:
  hero-heading:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  page-heading:
    fontFamily: Inter
    fontSize: 22px
    fontWeight: '600'
    lineHeight: '1.3'
  section-heading:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: '1.4'
  body:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  meta:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
  micro:
    fontFamily: Inter
    fontSize: 10px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  gutter-mobile: 16px
  gutter-desktop: 24px
  container-max: 1200px
  touch-target: 44px
---

# Design Specification: XMUM Market

## Design Tokens

### Colors
- **Primary:** Deep Navy Blue — `#003366`
- **Accent:** Vibrant Sky Blue — `#0055CC`
- **Success:** Emerald — `#10B981`
- **Warning:** Amber — `#F59E0B`
- **Danger:** Rose — `#EF4444`

**Light Mode Surface & Background:**
- **Background:** `#F8FAFC`
- **Surface:** `#FFFFFF`
- **Border:** `#E2E8F0`
- **Text Primary:** `#0F172A`
- **Text Secondary:** `#64748B`

**Dark Mode Surface & Background:**
- **Background:** `#0F172A`
- **Surface:** `#1E293B`
- **Border:** `#334155`
- **Text Primary:** `#F1F5F9`
- **Text Secondary:** `#94A3B8`

### Typography
- **Font Family:** Inter, system-ui
- **Display/Hero Heading:** 28px, Bold (700)
- **Page Heading:** 22px, Semibold (600)
- **Section Heading:** 16px, Semibold (600)
- **Body Text:** 14px, Regular (400)
- **Caption/Meta:** 12px, Regular (400)
- **Micro Label:** 10px, Medium (500)

### Spacing & Radius
- **Base Unit:** 4px
- **Border Radius:**
  - **Small (Pill):** 9999px
  - **Medium (Cards/Inputs):** 12px
  - **Large (Modals):** 20px
  - **Extra Large (Hero):** 24px

### Elevation (Shadows)
- **Card:** `0 1px 3px rgba(0,0,0,0.07), 0 1px 2px rgba(0,0,0,0.05)`
- **Hover Card:** `0 4px 12px rgba(0,0,0,0.1)`
- **Modal:** `0 20px 60px rgba(0,0,0,0.2)`
- **Bottom Sheet:** `0 -4px 20px rgba(0,0,0,0.1)`

---

## Component Library

### Buttons
- **Primary:** Background `#003366`, Text `#FFFFFF`, Radius 12px.
- **Secondary:** Border 1px `#003366`, Text `#003366`, Background Transparent.
- **Danger:** Background `#EF4444`, Text `#FFFFFF`.
- **Ghost:** Background Transparent, Text `#64748B`.
- **Loading State:** Replace label with SVG spinner, `pointer-events: none`, opacity 0.7.

### Inputs
- **Text Input:** Height 48px, Border 1px `#E2E8F0`, Radius 12px.
- **Focused State:** Border 2px `#0055CC`, Box-shadow `0 0 0 4px rgba(0, 85, 204, 0.1)`.
- **Error State:** Border 1px `#EF4444`, red caption text below.

### Listing Card
- **Structure:** Image (Top, 4:3), Info (Bottom).
- **Elements:** Price (Bold Primary), Title (14px Primary), Meta (12px Secondary), Type Badge (Overlay Top-Left).

---

## Screen 1: Splash / Onboarding

### Layout
- Full-screen container with centered logo and bottom-aligned actions.

### Elements
- **Logo:** Navy square icon with white "X", bold "XMUM Market" wordmark.
- **Tagline:** 16px Semibold, color `#64748B`.
- **Illustration Cards:** 3x horizontal scrollable cards (280px width).
  - Card A: "Buy & Sell" + Shopping Bag icon.
  - Card B: "Lost & Found" + Magnifying Glass icon.
  - Card C: "Jobs & Rentals" + Briefcase icon.
- **Buttons:** 
  - "Sign In with XMUM Email": Full-width, `#003366`.
  - "Create Account": Ghost style below.
- **Footer:** 10px caption: "Only for @xmu.edu.my email addresses".

### Mobile
- Stacked layout, full-width buttons (padding 16px).

### Desktop
- Max-width 400px container for onboarding flow, centered on page.

---

## Screen 2: Authentication Modal

### States
- **State A (Sign In):** Email, Password inputs. "Forgot Password?" link. "Sign In" Primary button.
- **State B (Create Account):** Display Name, Full Name, Email, Password. 
  - **Strength Meter:** 4-segment bar (Red, Orange, Yellow, Green).
- **State C (Forgot Password):** Email input, "Send Reset Email" button.

### Elements
- **Logo:** Small version at top center.
- **Close Button:** Top right 'X' (44x44px hit area).
- **Validation:** 12px Red text below inputs for errors.

---

## Screen 3: Home Page (Main Feed)

### Layout
- **Header:** Sticky, Background `#003366`.
- **Body:** Scrollable feed with Search -> Categories -> Listings.

### Elements
- **Sticky Header:** Logo (Left), Language toggle + Notification Bell (Right).
- **Hero Search:** White background card with shadow. 
  - Input: "Search listings..." with `#64748B` icon.
- **Category Tabs:** Horizontal pills: Buy & Sell, Lost & Found, Jobs, Assistance, Rentals.
- **Listings Grid:** 2-column mobile, 4-column desktop.

### Mobile
- Bottom Navigation: Home, Search, Messages, Post, Profile.
- FAB: Navy circle with white '+' for posting.

---

## Screen 4: Search Page

### Layout
- Full-width search bar at top with back button.
- Filter chips below header.

### Elements
- **Filter Row:** "Filters" button with icon, Sort dropdown (Newest/Price).
- **Filter Sheet:** Price range slider, Category multi-select, Condition toggle.
- **Results:** "24 results for 'laptop'" text (14px Semibold).

---

## Screen 5: Listing Detail Page

### Layout
- Image gallery (Top) -> Info Section -> Seller Card -> Action Bar (Sticky Bottom).

### Elements
- **Gallery:** 4:3 Aspect ratio, horizontal swipe.
- **Info:** Large Title (22px), Large Price (18px Bold).
- **Seller Card:** Avatar, Name, Verified Badge, Rating.
- **Action Bar:** "Message Seller" (60% width), WhatsApp icon (Green).

---

## Screen 6: Listing Card Component

### Elements
- **Thumbnail:** 4:3 ratio with lazy loading placeholder.
- **Badges:** 
  - Type: Absolute Top-Left.
  - Condition: Inline with Title.
- **Text:** 1-line Title (Truncated), Price (Bold), Timestamp.

---

## Screen 7: Post Listing Page

### Layout
- Multi-step or long-form scroll with sticky footer.

### Elements
- **Type Selector:** Pill tabs at top.
- **Fields:** Photo upload grid, Title, Description, Price, Category, Condition, Contact Info.
- **Submit:** "Post Listing" Primary button with loading spinner.

---

## Screen 8: Messages Page

### Layout
- **Mobile:** List of conversations -> Full-screen chat.
- **Desktop:** Two-pane (Sidebar 30%, Chat 70%).

### Elements
- **List Row:** Avatar, Name, Listing Thumbnail, Last Msg, Unread Dot.
- **Chat View:** Sticky header with listing info, Bubbles (Sent: Navy, Received: Grey).

---

## Screen 9: Profile Page (My Listings)

### Elements
- **Header:** Large Avatar, Stats (Listings/Sold), Settings icon.
- **Tabs:** Active, Sold, Archived, Saved.
- **Actions:** Edit, Delete, Mark Sold, Bump.

---

## Screen 10: Seller / Shop Profile

### Elements
- **Hero:** Navy gradient background, centered avatar.
- **Public Stats:** "Member since...", "X Listings".
- **Grid:** All active listings from this seller.

---

## Screen 11: Settings Page

### Elements
- **Sections:** Profile, Privacy, Security, Appearance (Dark Mode Toggle), Account.
- **Rows:** iOS-style with chevron icons.

---

## Screen 12: Notifications Panel

### Elements
- **List:** Icon + Title + Body text.
- **Action:** "Mark all as read" button.

---

## Screen 13: Report Modal

### Elements
- **Categories:** Spam, Scam, Offensive, Prohibited, Wrong Category, Other.
- **Textarea:** "Why are you reporting this?" (Min 10 chars).

---

## Screen 14: Rental T&C Modal

### Layout
- Non-dismissible full-screen overlay.
- Large warning icon and bold text paragraphs.
- Checkbox + Primary button ("I Agree").

---

## Responsive Breakpoints
- **Mobile:** 375px - 767px (Bottom Nav, Bottom Sheets).
- **Tablet:** 768px - 1023px (3-col Grid, Dialogs).
- **Desktop:** 1024px+ (Sticky Top Nav, 4-col Grid, Max-width 1200px).

## Motion & Animation
- **Standard:** 200ms ease-in-out.
- **Modals:** Slide up (Mobile) or Scale In (Desktop).
- **Feedback:** Haptic vibration on success/error (Mobile).